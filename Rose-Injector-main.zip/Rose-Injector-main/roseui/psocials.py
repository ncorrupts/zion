import webbrowser 

def open_xpierroz():
    webbrowser.open("https://github.com/xpierroz")

def open_xpierroz_insta():
    webbrowser.open("https://www.instagram.com/_p.slm/")

def open_S1LKT0UCH():
    webbrowser.open("https://github.com/S1LKT0UCH")

def open_suegdu():
    webbrowser.open("https://github.com/suegdu")

def open_svn():
    webbrowser.open("https://github.com/suvan1911")

def open_rose_github():
    webbrowser.open("https://github.com/DamagingRose/Rose-Injector")

def open_rose_discord():
    webbrowser.open("https://discord.gg/GqfffnxYWc")
