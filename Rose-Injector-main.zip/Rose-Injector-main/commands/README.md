```
┌─┐┌─┐┌─┐┌┬┐┬ ┬┬─┐┌─┐┌─┐
├┤ ├┤ ├─┤ │ │ │├┬┘├┤ └─┐
└  └─┘┴ ┴ ┴ └─┘┴└─└─┘└─┘  list 

[System]
Startup: starts the grabber on every startup
Injector: injects a js file that logs every logout/login/discord nitro buying actions

[Grabber]
Token: Grabs every Discord token
Cookies: Grabs cookies 
Password: Grabs passwords
Screenshot: make a screenshot and send it when the grabber is started
Malicious: Grabs multiples informations such as system data/wifi passwords
Location: Grabs the approximative location and send it
Roblox: Grabs Roblox accounts 

[Advanced]
RAT: Runs a RAT on the victim's computer. (see github.com/DamagingRose/Rose-RAT)
Ping: ping @everyone once the grabber is started 
```
